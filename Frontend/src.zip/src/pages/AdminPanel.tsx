/**
 * Admin Panel Page
 * Central dashboard for managing permissions, access requests, and viewing audit logs
 */

import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import { PendingRequests } from '@/components/admin/PendingRequests';
import { UserPermissions } from '@/components/admin/UserPermissions';
import { AuditLogs } from '@/components/admin/AuditLogs';

type TabType = 'requests' | 'permissions' | 'audit';

export const AdminPanel: React.FC = () => {
    const { isAdmin, isLoading } = useAuth();
    const [activeTab, setActiveTab] = useState<TabType>('requests');

    if (isLoading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    if (!isAdmin) {
        return <Navigate to="/access-denied" replace />;
    }

    const tabs = [
        { id: 'requests' as TabType, name: 'Pending Requests', icon: '📋' },
        { id: 'permissions' as TabType, name: 'User Permissions', icon: '👥' },
        { id: 'audit' as TabType, name: 'Audit Logs', icon: '📊' },
    ];

    return (
        <div className="min-h-screen bg-gray-50">
            <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
                {/* Header */}
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
                    <p className="mt-2 text-gray-600">
                        Manage user permissions, review access requests, and monitor system activity.
                    </p>
                </div>

                {/* Tabs */}
                <div className="bg-white shadow-sm rounded-lg">
                    <div className="border-b border-gray-200">
                        <nav className="-mb-px flex space-x-8 px-6" aria-label="Tabs">
                            {tabs.map((tab) => (
                                <button
                                    key={tab.id}
                                    onClick={() => setActiveTab(tab.id)}
                                    className={`
                    whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2
                    ${activeTab === tab.id
                                            ? 'border-blue-500 text-blue-600'
                                            : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                        }
                  `}
                                >
                                    <span>{tab.icon}</span>
                                    {tab.name}
                                </button>
                            ))}
                        </nav>
                    </div>

                    {/* Tab Content */}
                    <div className="p-6">
                        {activeTab === 'requests' && <PendingRequests />}
                        {activeTab === 'permissions' && <UserPermissions />}
                        {activeTab === 'audit' && <AuditLogs />}
                    </div>
                </div>
            </div>
        </div>
    );
};
