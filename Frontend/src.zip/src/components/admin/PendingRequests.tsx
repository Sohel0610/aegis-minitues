/**
 * Pending Requests Component
 * Shows and manages pending access requests
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import {
    getAccessRequests,
    approveAccessRequest,
    rejectAccessRequest,
    type AccessRequestResponse,
} from '@/services/permissionService';

export const PendingRequests: React.FC = () => {
    const { user } = useAuth();
    const [requests, setRequests] = useState<AccessRequestResponse[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [processingId, setProcessingId] = useState<number | null>(null);

    const loadRequests = async () => {
        if (!user) return;

        try {
            setLoading(true);
            setError(null);
            const data = await getAccessRequests(user.email, 'pending');
            setRequests(data.requests);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to load requests');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadRequests();
    }, [user]);

    const handleApprove = async (requestId: number) => {
        if (!user) return;

        setProcessingId(requestId);
        try {
            await approveAccessRequest(user.email, requestId);
            await loadRequests(); // Reload requests
        } catch (err) {
            alert(err instanceof Error ? err.message : 'Failed to approve request');
        } finally {
            setProcessingId(null);
        }
    };

    const handleReject = async (requestId: number) => {
        if (!user) return;

        const reason = prompt('Please provide a reason for rejection (optional):');
        if (reason === null) return; // User cancelled

        setProcessingId(requestId);
        try {
            await rejectAccessRequest(user.email, requestId, reason || undefined);
            await loadRequests(); // Reload requests
        } catch (err) {
            alert(err instanceof Error ? err.message : 'Failed to reject request');
        } finally {
            setProcessingId(null);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-700">{error}</p>
            </div>
        );
    }

    if (requests.length === 0) {
        return (
            <div className="text-center py-12">
                <svg
                    className="mx-auto h-12 w-12 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No pending requests</h3>
                <p className="mt-1 text-sm text-gray-500">All access requests have been processed.</p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-gray-900">
                    Pending Requests ({requests.length})
                </h2>
                <button
                    onClick={loadRequests}
                    className="text-sm text-blue-600 hover:text-blue-700"
                >
                    Refresh
                </button>
            </div>

            {requests.map((request) => (
                <div
                    key={request.id}
                    className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                >
                    <div className="flex justify-between items-start">
                        <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                                <h3 className="text-lg font-semibold text-gray-900">{request.name}</h3>
                                <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded">
                                    Pending
                                </span>
                            </div>

                            <div className="space-y-2 text-sm text-gray-600">
                                <p>
                                    <strong>Email:</strong> {request.email}
                                </p>
                                <p>
                                    <strong>Route:</strong>{' '}
                                    <code className="bg-gray-100 px-2 py-1 rounded">{request.requested_route}</code>
                                </p>
                                <p>
                                    <strong>Permission:</strong>{' '}
                                    <span className="capitalize font-medium">{request.requested_permission}</span>
                                </p>
                                <p>
                                    <strong>Requested:</strong>{' '}
                                    {new Date(request.requested_at).toLocaleString()}
                                </p>
                            </div>

                            <div className="mt-4 bg-gray-50 rounded-lg p-4">
                                <p className="text-sm font-medium text-gray-700 mb-1">Justification:</p>
                                <p className="text-sm text-gray-600">{request.justification}</p>
                            </div>
                        </div>
                    </div>

                    <div className="mt-4 flex gap-3">
                        <button
                            onClick={() => handleApprove(request.id)}
                            disabled={processingId === request.id}
                            className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                        >
                            {processingId === request.id ? 'Processing...' : 'Approve'}
                        </button>
                        <button
                            onClick={() => handleReject(request.id)}
                            disabled={processingId === request.id}
                            className="flex-1 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                        >
                            {processingId === request.id ? 'Processing...' : 'Reject'}
                        </button>
                    </div>
                </div>
            ))}
        </div>
    );
};
