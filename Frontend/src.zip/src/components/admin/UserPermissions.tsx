/**
 * User Permissions Component
 * View and manage all user permissions
 */

import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { getRoutePermissions, assignPermission, revokePermission } from '@/services/permissionService';

export const UserPermissions: React.FC = () => {
    const { user } = useAuth();
    const [selectedRoute, setSelectedRoute] = useState('/bse-alerts');
    const [permissions, setPermissions] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);

    const routes = [
        '/bse-alerts',
        '/rbi-dashboard',
        '/sebi-dashboard',
        '/insider-trading',
        '/directors-disclosure',
        '/minutes-preparation',
    ];

    const loadPermissions = async () => {
        if (!user) return;

        setLoading(true);
        try {
            const data = await getRoutePermissions(user.email, selectedRoute);
            setPermissions(data.permissions || []);
        } catch (err) {
            console.error('Failed to load permissions:', err);
        } finally {
            setLoading(false);
        }
    };

    React.useEffect(() => {
        loadPermissions();
    }, [selectedRoute, user]);

    const handleRevoke = async (email: string) => {
        if (!user) return;
        if (!confirm(`Revoke access for ${email}?`)) return;

        try {
            await revokePermission(user.email, email, selectedRoute);
            await loadPermissions();
        } catch (err) {
            alert('Failed to revoke permission');
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Route</label>
                <select
                    value={selectedRoute}
                    onChange={(e) => setSelectedRoute(e.target.value)}
                    className="w-full max-w-md px-4 py-2 border border-gray-300 rounded-lg"
                >
                    {routes.map((route) => (
                        <option key={route} value={route}>
                            {route}
                        </option>
                    ))}
                </select>
            </div>

            {loading ? (
                <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
            ) : (
                <div className="bg-white border rounded-lg overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Email
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Permission
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                                    Assigned
                                </th>
                                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {permissions.map((perm, idx) => (
                                <tr key={idx}>
                                    <td className="px-6 py-4 text-sm text-gray-900">{perm.email}</td>
                                    <td className="px-6 py-4 text-sm">
                                        <span
                                            className={`px-2 py-1 rounded text-xs font-medium ${perm.permission_type === 'admin'
                                                    ? 'bg-purple-100 text-purple-800'
                                                    : 'bg-blue-100 text-blue-800'
                                                }`}
                                        >
                                            {perm.permission_type}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-500">
                                        {new Date(perm.assigned_at).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 text-right text-sm">
                                        <button
                                            onClick={() => handleRevoke(perm.email)}
                                            className="text-red-600 hover:text-red-900"
                                        >
                                            Revoke
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {permissions.length === 0 && (
                        <div className="text-center py-12 text-gray-500">No permissions found</div>
                    )}
                </div>
            )}
        </div>
    );
};
